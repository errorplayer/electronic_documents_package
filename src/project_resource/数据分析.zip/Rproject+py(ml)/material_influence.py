from sklearn.preprocessing import  MinMaxScaler
import numpy as np
import matplotlib.pyplot as plt
from time import time
from sklearn import tree




def Start_ML(model_select = 1,around_eight = False):

    outer_dict = {}

    for i in range(0,27):
        inner_list = []
        for j in range(1,41):
          raw_dict = {}
          raw_dict["SS"] = 0
          raw_dict["FID"] = j-1
          inner_list.append(raw_dict)
        outer_dict[str(i)] = inner_list


    import csv
    csvfile = file("C:/Users/ErrorPlayer/Desktop/innerP/training_points.csv","rb")
    reader = csv.DictReader(csvfile, fieldnames=None)
    for row in reader:
        LID = str(row['Location_ID'])
        index = int(row['feature_ID'])
        outer_dict[LID][index]['SS'] =int(row['Strength'])
        #print row



    f_train = np.array([])
    L = []
    for i in range(0,27):
        if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
              ll  = np.array([])
              for j in range(1,40):
                 ll= np.append(ll,outer_dict[str(i)][j]['SS'])
              L.append(ll)
    f_train = np.array(L)



    print "f_train:"
    print f_train
    print "=================="
    t = []
    for i in range(0,27):
        tutu = (i,0)
        t.append(tutu)


    t[16] = (15,1)
    t[17] = (14,1)
    t[18]= (15,-1)

    t[21] = (5,1)
    t[22] = (6,1)
    t[23] = (7,1)
    t[20] = (5,-1)
    t[19] = (6,-1)
    t[24] = (7,-1)
    t[25] = (5,-2)
    t[26] = (6,-2)

    tt = []
    for i in range(0,27):
        if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                  tt.append(t[i])



    l_train = np.array(tt)
    print "l_train:"
    print l_train
    print "=================="

    print "y_l_train:"
    y_l_train = np.array([])
    for i in range(0,len(l_train)):
        y_l_train= np.append(y_l_train,l_train[i][1])
    print y_l_train
    print "=================="

    print "x_l_train:"
    x_l_train = np.array([])
    for i in range(0,len(l_train)):
        x_l_train= np.append(x_l_train,l_train[i][0])
    print x_l_train
    print "=================="


    outer_dict = {}

    f7 = new_a_list_for_feature()
    csvfile = file("C:/Users/ErrorPlayer/Desktop/innerP/pic7_mean.csv","rb")
    reader = csv.DictReader(csvfile, fieldnames=None)
    for row in reader:
        index = int(row['feature_ID'])
        f7[index]=float(row['Strength_mean'])



    f8 = new_a_list_for_feature()
    csvfile = file("C:/Users/ErrorPlayer/Desktop/innerP/pic8_mean.csv","rb")
    reader = csv.DictReader(csvfile, fieldnames=None)
    for row in reader:
        index = int(row['feature_ID'])
        f8[index]=float(row['Strength_mean'])

    f9 = new_a_list_for_feature()
    csvfile = file("C:/Users/ErrorPlayer/Desktop/innerP/pic9_mean.csv","rb")
    reader = csv.DictReader(csvfile, fieldnames=None)
    for row in reader:
        index = int(row['feature_ID'])
        f9[index]=float(row['Strength_mean'])


    f10 = new_a_list_for_feature()
    csvfile = file("C:/Users/ErrorPlayer/Desktop/innerP/pic10_mean.csv","rb")
    reader = csv.DictReader(csvfile, fieldnames=None)
    for row in reader:
        index = int(row['feature_ID'])
        f10[index]=float(row['Strength_mean'])








    L = []
    L.append(f7)
    f_test7 = np.array(L)

    L = []
    L.append(f8)
    f_test8 = np.array(L)

    L = []
    L.append(f9)
    f_test9 = np.array(L)

    L = []
    L.append(f10)
    f_test10 = np.array(L)
    print "f_test:"
    print(f_test7)
    print (f_test8)
    print (f_test9)
    print (f_test10)
    print "=================="


    if (model_select ==1):
        a1  = LinearRegression_ML(f_train,l_train,f_test7)
        a2  = LinearRegression_ML(f_train,l_train,f_test8)
        a3  = LinearRegression_ML(f_train,l_train,f_test9)
        a4  = LinearRegression_ML(f_train,l_train,f_test10)


        plt.subplot(221)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a1[0][0],a1[0][1],color="b")
        plt.title("towards_west", size=7)
        plt.subplot(222)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a2[0][0],a2[0][1],color="b")
        plt.title("towards_east", size=7)
        plt.subplot(223)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a3[0][0],a3[0][1],color="b")
        plt.title("towards_south", size=7)
        plt.subplot(224)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a4[0][0],a4[0][1],color="b")
        plt.title("towards_north", size=7)
        maintitle = "LinearRegression_Figures "
        plt.suptitle(maintitle,fontsize=16)
        plt.savefig("..\LR_material_influence.png")
        plt.show()

    if (model_select ==1):
        a1  = DecisionTree_ML(f_train,l_train,f_test7,1000)
        a2  = DecisionTree_ML(f_train,l_train,f_test8,1000)
        a3  = DecisionTree_ML(f_train,l_train,f_test9,1000)
        a4  = DecisionTree_ML(f_train,l_train,f_test10,1000)



        plt.subplot(221)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a1[0],a1[1],color="b")
        plt.title("towards_west", size=7)
        plt.subplot(222)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a2[0],a2[1],color="b")
        plt.title("towards_east", size=7)
        plt.subplot(223)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a3[0],a3[1],color="b")
        plt.title("towards_south", size=7)
        plt.subplot(224)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a4[0],a4[1],color="b")
        plt.title("towards_north", size=7)
        maintitle = "DecisionTree_Figures "
        plt.suptitle(maintitle,fontsize=16)
        plt.savefig("..\DT_material_influence.png")
        plt.show()

    if (model_select ==1):
        a1  = SVC_ML(f_train,x_l_train,f_test7,1000)
        a2  = SVC_ML(f_train,y_l_train,f_test7,1000)
        a3  = SVC_ML(f_train,x_l_train,f_test8,1000)
        a4  = SVC_ML(f_train,y_l_train,f_test8,1000)
        a5  = SVC_ML(f_train,x_l_train,f_test9,1000)
        a6  = SVC_ML(f_train,y_l_train,f_test9,1000)
        a7  = SVC_ML(f_train,x_l_train,f_test10,1000)
        a8  = SVC_ML(f_train,y_l_train,f_test10,1000)


        plt.subplot(221)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a1,a2,color="b")
        plt.title("towards_west", size=7)
        plt.subplot(222)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a3,a4,color="b")
        plt.title("towards_east", size=7)
        plt.subplot(223)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a5,a6,color="b")
        plt.title("towards_south", size=7)
        plt.subplot(224)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a7,a8,color="b")
        plt.title("towards_north", size=7)
        maintitle = "SVC_Figures "
        plt.suptitle(maintitle,fontsize=16)
        plt.savefig("..\SVC_material_influence.png")
        plt.show()


    if (model_select ==1):
        a1  = GaussianNB_ML(f_train,x_l_train,f_test7,1000)
        a2  = GaussianNB_ML(f_train,y_l_train,f_test7,1000)
        a3  = GaussianNB_ML(f_train,x_l_train,f_test8,1000)
        a4  = GaussianNB_ML(f_train,y_l_train,f_test8,1000)
        a5  = GaussianNB_ML(f_train,x_l_train,f_test9,1000)
        a6  = GaussianNB_ML(f_train,y_l_train,f_test9,1000)
        a7  = GaussianNB_ML(f_train,x_l_train,f_test10,1000)
        a8  = GaussianNB_ML(f_train,y_l_train,f_test10,1000)


        plt.subplot(221)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a1,a2,color="b")
        plt.title("towards_west", size=7)
        plt.subplot(222)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a3,a4,color="b")
        plt.title("towards_east", size=7)
        plt.subplot(223)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a5,a6,color="b")
        plt.title("towards_south", size=7)
        plt.subplot(224)
        for i in range(0,27):
                if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                                plt.scatter(t[i][0],t[i][1],color="r")
        plt.scatter(a7,a8,color="b")
        plt.title("towards_north", size=7)
        maintitle = "GaussianNB_Figures "
        plt.suptitle(maintitle,fontsize=16)
        plt.savefig("..\GaussianNB_material_influence.png")
        plt.show()















def DecisionTree_ML(features_train,labels_train,features_test,c):
    from time import time
    from sklearn import tree
    print "DecisionTree_ML"
    t1 = time()
    print "DT [solutions]:"

    total_x = 0
    total_y = 0
    for i in range(0,c):
        clf_DT1 = tree.DecisionTreeClassifier()
        clf_DT1.fit(features_train,labels_train)
        answer = clf_DT1.predict(features_test)
        total_x = total_x +answer[0][0]
        total_y = total_y +answer[0][1]
    answer_x = float(total_x)/c
    answer_y = float(total_y)/c
    answer = (answer_x,answer_y)
    print answer
    t2 = time()
    print "DT [total time]:", round(t2-t1, 3), "s  ","times:",c
    print "======================="
    return answer

def LinearRegression_ML(features_train,labels_train,features_test):
    from time import time
    from sklearn import linear_model
    print "LinearRegression_ML"
    reg = linear_model.LinearRegression()
    t0 = time()
    reg.fit(features_train,labels_train)
    t1 = time()
    print "LR [training time]:", round(t1-t0, 3), "s"
    print "LR [solutions]:"
    answer = reg.predict(features_test)
    print answer
    t2 = time()
    print "LR [predicting time]:", round(t2-t1, 3), "s"
    print "======================="
    return answer

def SVC_ML(features_train,labels_train,features_test,c):
    from time import time
    from sklearn import svm
    print "SVC_ML"

    t1 = time()

    print "SVC [solutions]:"
    total = 0
    for i in range(0,c):
        SVC1 = svm.SVC(kernel = "linear",C=i+6)
        SVC1.fit(features_train,labels_train)
        answer = SVC1.predict(features_test)
        total = total +answer[0]


    answer = float(total) /c

    print answer
    t2 = time()
    print "SVC [total time]:", round(t2-t1, 3), "s  ","times:",c

    print "======================="
    return answer

def GaussianNB_ML(features_train,labels_train,features_test,c):
    from time import time
    from sklearn.naive_bayes import GaussianNB
    from sklearn.naive_bayes import MultinomialNB
    print "GaussianNB_ML"
    GaussianNB = GaussianNB()

    t1 = time()

    print "GaussianNB [solutions]:"

    total = 0
    for i in range(0,c):
        #GaussianNB1 = GaussianNB()
        GaussianNB.fit(features_train,labels_train)
        answer = GaussianNB.predict(features_test)
        total = total +answer[0]
    answer = float(total) /float(c)
    print answer
    t2 = time()
    print "GaussianNB [total time]:", round(t2-t1, 3), "s  ","times:",c

    print "======================="
    return answer







def new_a_list_for_feature():
    inner_list = []
    for j in range(1,40):

        inner_list.append(0)
    return inner_list


#��ʾ������ֻ����Χ8��λ�����ݵ�ѵ���Ľ����
Start_ML()



print "No line to be executed !"















