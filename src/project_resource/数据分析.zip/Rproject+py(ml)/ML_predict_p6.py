from sklearn.preprocessing import  MinMaxScaler
import numpy as np
import matplotlib.pyplot as plt
from time import time
from sklearn import tree

x_train = np.array([[10,30,50,90],
                    [70,20,40,10],
                    [50,50,30,90]])
#scaler = MinMaxScaler(feature_range=(0,1))
#s_x_train = scaler.fit_transform(x_train)
y_train = np.array([(12,21),(23,26),(29,34)])
x_test = np.array([[12, 90,55,10],
                   [46,43,29,132]])

#print y_train
#print clf.score(x_train,y_train)


def Start_ML(file_addr="0",around_eight = False,wrong_fit = False):
   
    outer_dict = {}
    
    for i in range(0,27):
        inner_list = []
        for j in range(1,40):
          raw_dict = {}
          raw_dict["SS"] = 0
          raw_dict["FID"] = j-1
          inner_list.append(raw_dict)
        outer_dict[str(i)] = inner_list

    
    import csv
    csvfile = file("C:/Users/ErrorPlayer/Desktop/innerP/"+file_addr,"rb")
    reader = csv.DictReader(csvfile, fieldnames=None)
    for row in reader:
        LID = str(row['Location_ID'])
        index = int(row['feature_ID'])
        outer_dict[LID][index]['SS'] =int(row['Strength'])
        #print row

    if 0: #for displaying
      for i in range(0,27):
        if i in(5,7):
            print i,"========="
            for j in range(1,39):
               print outer_dict[str(i)][j]

    f_train = np.array([])
    L = []
    for i in range(0,27):
        if wrong_fit or i !=6 :
           if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
              ll  = np.array([])
              for j in range(1,39):
                 ll= np.append(ll,outer_dict[str(i)][j]['SS'])
              L.append(ll)
    f_train = np.array(L)

    
        
    print "f_train:"
    print f_train
    print "=================="
    t = []
    for i in range(0,27):
        tutu = (i,0)
        t.append(tutu)
    

    t[16] = (15,1)
    t[17] = (14,1)
    t[18]= (15,-1)
    
    t[21] = (5,1)
    t[22] = (6,1)
    t[23] = (7,1)
    t[20] = (5,-1)
    t[19] = (6,-1)
    t[24] = (7,-1)
    t[25] = (5,-2)
    t[26] = (6,-2)

    tt = []
    for i in range(0,27):
        if wrong_fit or i !=6 :
            if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                  tt.append(t[i])
    
    
        
    l_train = np.array(tt)
    print "l_train:"
    print l_train
    print "=================="

    print "y_l_train:"
    y_l_train = np.array([])
    for i in range(0,len(l_train)):
        y_l_train= np.append(y_l_train,l_train[i][1])
    print y_l_train
    print "=================="

    print "x_l_train:"
    x_l_train = np.array([])
    for i in range(0,len(l_train)):
        x_l_train= np.append(x_l_train,l_train[i][0])
    print x_l_train
    print "==================" 

    f_test = np.array([])
    L = []
    ll  = np.array([])
    for j in range(1,39):
        ll= np.append(ll,outer_dict['6'][j]['SS'])
    L.append(ll)
    f_test = np.array(L)
    print "f_test:"
    print f_test
    print "=================="
    
    a1 = DecisionTree_ML(f_train,l_train,f_test,1171)
    a2 = LinearRegression_ML(f_train,l_train,f_test)
    a3 = SVC_ML(f_train,x_l_train,f_test,1061)
    a4 = SVC_ML(f_train,y_l_train,f_test,1061)
    a5 = GaussianNB_ML(f_train,x_l_train,f_test,1591)
    a6 = GaussianNB_ML(f_train,y_l_train,f_test,1591)
    

    
    plt.subplot(221)
    for i in range(0,27):
        if wrong_fit or i !=6 :
            if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                plt.scatter(t[i][0],t[i][1],color="r")
    plt.scatter(a1[0],a1[1],color="b")
    plt.title("DecisionTree", size=7)
    plt.subplot(222)
    for i in range(0,27):
        if wrong_fit or i !=6 :
            if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                plt.scatter(t[i][0],t[i][1],color="r")
    plt.scatter(a2[0][0],a2[0][1],color="b")
    plt.title("LinearRegression", size=7)
    plt.subplot(223)
    for i in range(0,27):
        if wrong_fit or i !=6 :
            if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                plt.scatter(t[i][0],t[i][1],color="r")
    plt.scatter(a3,a4,color="b")
    plt.title("Support Vector Classifier", size=7)
    plt.subplot(224)
    for i in range(0,27):
        if wrong_fit or i !=6 :
            if (not around_eight) or ( i in (5,7,19,20,21,22,23,24)):
                plt.scatter(t[i][0],t[i][1],color="r")
    plt.scatter(a5,a6,color="b")
    plt.title("Gaussian-Naive Bayesian", size=7)

    maintitle = "ML_Figures "
    
       
    if wrong_fit:
       s1="wrong_fit "
       maintitle = maintitle + s1
    else:
       s1="normal "
       maintitle = maintitle + s1
    

    plt.suptitle(maintitle,fontsize=16)
    if around_eight == False  and wrong_fit ==True:
        plt.savefig("..\pic_1.png")

    if around_eight == True  and wrong_fit ==False:
        plt.savefig("..\pic_2.png")

    if around_eight == False  and wrong_fit ==False:
        plt.savefig("..\pic_3.png")

    
    plt.show()
   

    
    
    
    
def DecisionTree_ML(features_train,labels_train,features_test,c):
    from time import time
    from sklearn import tree
    print "DecisionTree_ML"
    t1 = time()
    print "DT [solutions]:"
    
    total_x = 0
    total_y = 0
    for i in range(0,c):
        clf_DT1 = tree.DecisionTreeClassifier()
        clf_DT1.fit(features_train,labels_train)
        answer = clf_DT1.predict(features_test)
        total_x = total_x +answer[0][0]
        total_y = total_y +answer[0][1]
    answer_x = float(total_x)/c
    answer_y = float(total_y)/c
    answer = (answer_x,answer_y)
    print answer
    t2 = time()
    print "DT [total time]:", round(t2-t1, 3), "s  ","times:",c
    print "======================="
    return answer

def LinearRegression_ML(features_train,labels_train,features_test):
    from time import time
    from sklearn import linear_model
    print "LinearRegression_ML"
    reg = linear_model.LinearRegression()
    t0 = time()
    reg.fit(features_train,labels_train)
    t1 = time()
    print "LR [training time]:", round(t1-t0, 3), "s"
    print "LR [solutions]:"
    answer = reg.predict(features_test)
    print answer
    t2 = time()
    print "LR [predicting time]:", round(t2-t1, 3), "s"
    print "======================="
    return answer

def SVC_ML(features_train,labels_train,features_test,c):
    from time import time
    from sklearn import svm
    print "SVC_ML"
    
    t1 = time()
    
    print "SVC [solutions]:"
    total = 0
    for i in range(0,c):
        SVC1 = svm.SVC(kernel = "linear",C=i+6)
        SVC1.fit(features_train,labels_train)
        answer = SVC1.predict(features_test)
        total = total +answer[0]
    
        
    answer = float(total) /c
    
    print answer
    t2 = time()
    print "SVC [total time]:", round(t2-t1, 3), "s  ","times:",c

    print "======================="
    return answer

def GaussianNB_ML(features_train,labels_train,features_test,c):
    from time import time
    from sklearn.naive_bayes import GaussianNB
    from sklearn.naive_bayes import MultinomialNB
    print "GaussianNB_ML"
    GaussianNB = GaussianNB()
    
    t1 = time()
    
    print "GaussianNB [solutions]:"
    
    total = 0
    for i in range(0,c):
        #GaussianNB1 = GaussianNB()
        GaussianNB.fit(features_train,labels_train)
        answer = GaussianNB.predict(features_test)
        total = total +answer[0]
    answer = float(total) /float(c)
    print answer
    t2 = time()
    print "GaussianNB [total time]:", round(t2-t1, 3), "s  ","times:",c

    print "======================="
    return answer









#pic_1.png（放入全部数据点包括位置6进行训练的结果）
Start_ML('training_points.csv',around_eight = False,wrong_fit =True)


#pic_2.png（放入只有周围8个位置数据点训练的结果）
Start_ML('training_points.csv',around_eight = True,wrong_fit =False)

#pic_3.png（放入全部位置数据点除了位置6训练的结果）
Start_ML('training_points.csv',around_eight = False,wrong_fit =False)


print "No line to be executed !"














def Draw(pred, features, poi, mark_poi=False, name="image.png", f1_name="feature 1", f2_name="feature 2"):
    """ some plotting code designed to help you visualize your clusters """
    import matplotlib.pyplot as plt
    ### plot each cluster with a different color--add more colors for
    ### drawing more than five clusters
    colors = ["b", "c", "k", "m", "g"]
    for ii, pp in enumerate(pred):
        plt.scatter(features[ii][0], features[ii][1], color = colors[pred[ii]])

    ### if you like, place red stars over points that are POIs (just for funsies)
    if mark_poi:
        for ii, pp in enumerate(pred):
            if poi[ii]:
                plt.scatter(features[ii][0], features[ii][1], color="r", marker="*")
    plt.xlabel(f1_name)
    plt.ylabel(f2_name)
    plt.savefig(name)
    plt.show()


#plt.scatter(1,2,color="b")
#plt.scatter(233,665,color="k")
#plt.scatter(6,9,color="r")
#plt.scatter(6,9,color="g")
#plt.xlabel("x_axis")
#plt.ylabel("y axis")
#plt.savefig("..\pic.png")
#plt.show()


#x_train = np.array([[10,30,50,90],
#             [70,20,40,10],
#             [50,50,30,90]])
#scaler = MinMaxScaler(feature_range=(0,1))
#s_x_train = scaler.fit_transform(x_train)
#print s_x_train

#print scaler.min_

#x_test = np.array([[100,20,199,100]])

#print scaler.transform(x_test)

#print x_train
#a= np.concatenate((x_train,x_test),axis=0)
#print  scaler.fit_transform(a)

#print scaler.min_
